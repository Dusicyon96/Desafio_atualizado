package br.com.juridico.totvs.fullstack.Backend.domain;

import java.time.LocalDate;

public class Comentario {
    private Long id;
    private String autor;
    private String comentario;
    private LocalDate dataCriacao;

    public Comentario(Long id, String autor, String comentario, LocalDate dataCriacao) {
        this.id = id;
        this.autor = autor;
        this.comentario = comentario;
        this.dataCriacao = dataCriacao;
    }
    public Comentario(Long id, String autor, String comentario, String dataCriacao, String resumo, Comentario Comentario) {
        this.id = id;
        this.autor = autor;
        this.comentario = comentario;
        this.dataCriacao = new ArrayList<>();
    }

    public Comentario(DTO ComentarioDTO){
        this.id = ComentarioDTO.getId();
        this.autor = ComentarioDTO.getautor();
        this.comentario = ComentarioDTO.getcomentario();
        this.dataCriacao = ComentarioDTO.getdataCriacao();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getcomentario() {
        return comentario;
    }

    public void setcomentario(String comentario) {
        this.comentario = comentario;
    }

    public String getautor() {
        return autor;
    }

    public void setautor(String autor) {
        this.autor = autor;
    }
    public int getdataCriacao() {
        return dataCriacao;
    }

    public void setdataCriacao(int dataCriacao) {
        this.dataCriacao = dataCriacao;}
}