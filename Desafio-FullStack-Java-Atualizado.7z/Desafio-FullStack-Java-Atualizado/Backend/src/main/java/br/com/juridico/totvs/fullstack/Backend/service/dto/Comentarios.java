ComentarioDTOpackage br.com.juridico.totvs.fullstack.Backend.service.dto;

public class ComentarioDTOCreateUpdateDTO {
    private Long id;
    private String autor;
    private String comentario;
    private LocalDate dataCriacao;

    public ComentarioDTO(Long id, String cidade, String nome, String estacao, String resumo, ComentarioDTO ComentarioDTO) {
        this.id = id;
        this.autor = autor;
        this.comentario = comentario;
        this.dataCriacao = new ArrayList<>();
    }

    public ComentarioDTO(ComentarioDTO ComentarioDTO){
        this.id = ComentarioDTO.getId();
        this.autor = ComentarioDTO.getautor();
        this.comentario = ComentarioDTO.getcomentario();
        this.dataCriacao = ComentarioDTO.getdataCriacao();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getcomentario() {
        return comentario;
    }

    public void setcomentario(String comentario) {
        this.comentario = comentario;
    }

    public String getautor() {
        return autor;
    }

    public void setautor(String autor) {
        this.autor = autor;
    }
    public int getdataCriacao() {
        return dataCriacao;
    }

    public void setdataCriacao(int dataCriacao) {
        this.dataCriacao = dataCriacao;}
}