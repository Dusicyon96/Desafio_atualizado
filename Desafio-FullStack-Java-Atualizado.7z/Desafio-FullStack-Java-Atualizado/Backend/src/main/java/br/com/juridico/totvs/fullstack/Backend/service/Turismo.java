package br.com.juridico.totvs.fullstack.Backend.service;

import br.com.juridico.totvs.fullstack.Backend.service.dto.PontoTuristicoCreateUpdateDTO;
import br.com.juridico.totvs.fullstack.Backend.service.dto.PontoTuristicoDTO;

import java.util.List;

public interface PontoTuristicoService {
    PontoTuristicoDTO create(PontoTuristicoCreateUpdateDTO pontoTuristicoCreateUpdateDTO);
    PontoTuristicoDTO update(Long id, PontoTuristicoCreateUpdateDTO pontoTuristicoCreateUpdateDTO);
    void delete(Long id);
    PontoTuristicoDTO getPontoTuristicoById(Long id);
    List<PontoTuristicoDTO> getAllPontosTuristicos();
}