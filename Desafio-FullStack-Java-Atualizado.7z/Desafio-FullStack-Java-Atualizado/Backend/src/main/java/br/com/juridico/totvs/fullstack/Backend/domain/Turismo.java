package br.com.juridico.totvs.fullstack.Backend.domain;

import java.util.ArrayList;
import java.util.List;

public class PontoTuristico {
    private Long id;
    private String cidade;
    private String nome;
    private String estacao;
    private String resumo;
    private PontoTuristico PontoTuristico;
    private List<Comentario> comentarios;

    public PontoTuristico(Long id, String cidade, String nome, String estacao, String resumo, PontoTuristico PontoTuristico) {
        this.id = id;
        this.cidade = cidade;
        this.nome = nome;
        this.estacao = estacao;
        this.resumo = resumo;
        this.PontoTuristico = PontoTuristico;
        this.comentarios = new ArrayList<>();
    }

    public PontoTuristico(DTO PontoTuristicoDTO){
        this.id = PontoTuristicoDTO.getId();
        this.cidade = PontoTuristicoDTO.getcidade();
        this.nome = PontoTuristicoDTO.getNome();
        this.estacao = PontoTuristicoDTO.getestacao();
        this.resumo = PontoTuristicoDTO.getresumo();
        this.PontoTuristico = PontoTuristicoDTO.getpontoturistico();
        this.comentarios = PontoTuristicoDTO.getcomentarios();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String Cidade) {
        this.Cidade = Cidade;
    }

    public String getContinente() {
        return continente;
    }

    public void setContinente(String continente) {
        this.continente = continente;
    }
    public int getEstacao() {
        return Estacao;
    }

    public void setEstacao(int Estacao) {
        this.Estacao = Estacao;}

    public int getResumo() {
        return Resumo;
    }

    public void setResumo(int Resumo) {
        this.Resumo = Resumo;}

        public int getPontoTuristico() {
            return PontoTuristico;
        }
    
        public void setPontoTuristico(int PontoTuristico) {
            this.PontoTuristico = PontoTuristico;}


        public int getcomentarios() {
            return comentarios;
        }
    
        public void setcomentarios(int comentarios) {
            this.comentarios = comentarios;}
                
}