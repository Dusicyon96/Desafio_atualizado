package br.com.juridico.totvs.fullstack.Backend.service;

import br.com.juridico.totvs.fullstack.Backend.domain.Pais;
import br.com.juridico.totvs.fullstack.Backend.repository.PaisRepository;
import br.com.juridico.totvs.fullstack.Backend.service.dto.PaisCreateUpdateDTO;
import br.com.juridico.totvs.fullstack.Backend.service.dto.PaisDTO;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaisServiceImpl implements PaisService {
    private final PaisRepository paisRepository;

    public PaisServiceImpl(PaisRepository paisRepository) {
        this.paisRepository = paisRepository;
    }

    @Override
    public PaisDTO create(PaisCreateUpdateDTO paisCreateUpdateDTO) {
        Pais pais = new Pais(paisCreateUpdateDTO.getNome(), paisCreateUpdateDTO.getSigla(),
                paisCreateUpdateDTO.getContinente(), paisCreateUpdateDTO.getDdi());
        Pais savedPais = paisRepository.save(pais);
        return new PaisDTO(savedPais);
    }

    @Override
    public PaisDTO update(Long id, PaisCreateUpdateDTO paisCreateUpdateDTO) {
        Pais pais = paisRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("País não encontrado com o ID fornecido."));
        pais.setNome(paisCreateUpdateDTO.getNome());
        pais.setSigla(paisCreateUpdateDTO.getSigla());
        pais.setContinente(paisCreateUpdateDTO.getContinente());
        pais.setDdi(paisCreateUpdateDTO.getDdi());
        Pais updatedPais = paisRepository.save(pais);
        return new PaisDTO(updatedPais);
    }

    @Override
    public void delete(Long id) {
        paisRepository.deleteById(id);
    }

    @Override
    public PaisDTO getPaisbyId(Long id) {
        Pais pais = paisRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("País não encontrado com o ID fornecido."));
        return new PaisDTO(pais);
    }

    @Override
    public List<PaisDTO> getPaisByContinente(String continente) {
        List<Pais> paises = paisRepository.findByContinente(continente);
        return PaisDTO.toDTOList(paises);
    }

    @Override
    public List<PaisDTO> getAllPais() {
        List<Pais> paises = paisRepository.findAll();
        return PaisDTO.toDTOList(paises);
    }
}
