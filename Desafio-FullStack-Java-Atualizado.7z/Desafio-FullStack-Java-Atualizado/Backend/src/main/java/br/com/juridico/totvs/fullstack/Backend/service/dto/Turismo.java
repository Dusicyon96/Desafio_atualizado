PontoTuristicoDTOpackage br.com.juridico.totvs.fullstack.Backend.service.dto;

public class PontoTuristicoDTOCreateUpdateDTO {
    private String cidade;
    private String nome;
    private String estacao;
    private String resumo;
    private Long paisId;

    public PontoTuristicoDTO(Long id, String cidade, String nome, String estacao, String resumo, PontoTuristicoDTO PontoTuristicoDTO) {
        this.id = id;
        this.cidade = cidade;
        this.nome = nome;
        this.estacao = estacao;
        this.resumo = resumo;
        this.PontoTuristico = PontoTuristico;
        this.comentarios = new ArrayList<>();
    }

    public PontoTuristicoDTO(PontoTuristicoDTO PontoTuristicoDTO){
        this.id = PontoTuristico.getId();
        this.cidade = PontoTuristico.getcidade();
        this.nome = PontoTuristico.getNome();
        this.estacao = PontoTuristico.getestacao();
        this.resumo = PontoTuristico.getresumo();
        this.PontoTuristico = PontoTuristico.getPontoTuristico();
        this.comentarios = PontoTuristico.getcomentarios();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String Cidade) {
        this.Cidade = Cidade;
    }

    public String getContinente() {
        return continente;
    }

    public void setContinente(String continente) {
        this.continente = continente;
    }
    public int getEstacao() {
        return Estacao;
    }

    public void setEstacao(int Estacao) {
        this.Estacao = Estacao;}

    public int getResumo() {
        return Resumo;
    }

    public void setResumo(int Resumo) {
        this.Resumo = Resumo;}

        public int getPontoTuristico() {
            return PontoTuristico;
        }
    
        public void setPontoTuristico(int PontoTuristico) {
            this.PontoTuristico = PontoTuristico;}


        public int getcomentarios() {
            return comentarios;
        }
    
        public void setcomentarios(int comentarios) {
            this.comentarios = comentarios;}
                
}
